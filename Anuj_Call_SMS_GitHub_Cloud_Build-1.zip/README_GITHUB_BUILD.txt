TABLET-ONLY BUILD NOTE

This ZIP contains a GitHub Actions workflow for cloud building.

IMPORTANT:
The Android project needs the Gradle wrapper files (gradlew, gradlew.bat and
gradle/wrapper/*) for the workflow to build it directly. If GitHub reports
"Gradle wrapper not found", use Android Studio once on a computer to generate
the wrapper, or use a cloud Android IDE that supplies Gradle.

GitHub steps:
1. Create a repository.
2. Upload all files/folders from this ZIP (including .github).
3. Open Actions.
4. Select "Build Android APK".
5. Run workflow.
6. Download the "anuj-call-sms-debug-apk" artifact.
