ANUJ CONFECTIONARY CALL-AFTER-SMS

Flow:
Incoming SIM call -> call ends -> automatic SMS to caller.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the APK on the Android phone containing the cafe SIM.
5. Grant Phone/Call Log/SMS permissions.
6. Set and save the message.
7. Test with your own number first.

Notes:
- This is designed for Android, not iPhone.
- SMS charges can apply.
- Android/Google Play restrictions can affect call/SMS permissions.
- Some phones may require battery/background permission adjustments.
